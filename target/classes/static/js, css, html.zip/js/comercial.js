// ============================================
// AUTOELITE - COMERCIAL.JS (CON IMÁGENES V2)
// ============================================

//const API_URL = 'http://localhost:8088/api/vehiculos';
const API_URL = 'http://localhost:8088/api/admin/vehiculos';
const TOKEN_KEY = 'autoelite_token';
const USER_KEY = 'autoelite_user';

// ============================================
// AUTENTICACIÓN
// ============================================

function setCurrentUser(user, token) {
    token = token || null;
    const userData = typeof user === 'string' ? user : JSON.stringify(user);
    localStorage.setItem(USER_KEY, userData);
    if (token) localStorage.setItem(TOKEN_KEY, token);
}

function getCurrentUser() {
    const possibleKeys = ['autoelite_user', 'user', 'usuario', 'currentUser', 'session'];

    for (let i = 0; i < possibleKeys.length; i++) {
        try {
            const raw = localStorage.getItem(possibleKeys[i]);
            if (!raw || raw === 'undefined' || raw === 'null') continue;

            const user = JSON.parse(raw);
            if (user && (user.id || user.nombre || user.email || user.correo)) {
                return {
                    id: user.id,
                    nombre: user.nombre || user.name || user.username || 'Usuario',
                    email: user.email || user.correo || '',
                    rol: (user.rol || user.role || '').toLowerCase()
                };
            }
        } catch (e) {
            continue;
        }
    }
    return null;
}

function getToken() {
    return localStorage.getItem(TOKEN_KEY);
}

function logout() {
    const keysToRemove = ['autoelite_user', 'user', 'usuario', 'currentUser', 'session', TOKEN_KEY];
    for (let i = 0; i < keysToRemove.length; i++) {
        localStorage.removeItem(keysToRemove[i]);
    }
    window.location.replace('login.html');
}

function checkAuth(allowedRoles) {
    allowedRoles = allowedRoles || [];
    const user = getCurrentUser();
    const currentPage = window.location.pathname.split('/').pop() || '';

    if (!user) {
        if (!currentPage.includes('login')) {
            window.location.replace('login.html');
        }
        return false;
    }

    const normalizedAllowed = [];
    for (let i = 0; i < allowedRoles.length; i++) {
        normalizedAllowed.push(allowedRoles[i].toLowerCase());
    }
    const userRol = user.rol;

    if (normalizedAllowed.length > 0 && normalizedAllowed.indexOf(userRol) === -1) {
        const rolPages = {
            'cliente': 'cliente-panel.html',
            'comercial': 'comercial-panel.html',
            'mecanico': 'mecanico-panel.html',
            'admin': 'admin-panel.html'
        };
        const targetPage = rolPages[userRol] || 'index.html';
        if (currentPage !== targetPage) {
            window.location.replace(targetPage);
            return false;
        }
    }

    return true;
}

// ============================================
// API - SPRING BOOT
// ============================================

function getHeaders() {
    const headers = { 'Content-Type': 'application/json' };
    const token = getToken();
    if (token) headers['Authorization'] = 'Bearer ' + token;
    return headers;
}

async function fetchVehiculos() {
    try {
        const response = await fetch(API_URL, { headers: getHeaders() });
        if (!response.ok) throw new Error('Error al cargar vehiculos');
        return await response.json();
    } catch (error) {
        console.error('Error API:', error);
        return getVehiculos();
    }
}

async function fetchVehiculoById(id) {
    try {
        const response = await fetch(API_URL + '/' + id, { headers: getHeaders() });
        if (!response.ok) throw new Error('Vehiculo no encontrado');
        return await response.json();
    } catch (error) {
        return null;
    }
}

async function createVehiculo(vehiculoData) {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify(vehiculoData)
        });
        if (!response.ok) throw new Error('Error al crear');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

async function updateVehiculo(id, vehiculoData) {
    try {
        const response = await fetch(API_URL + '/' + id, {
            method: 'PUT',
            headers: getHeaders(),
            body: JSON.stringify(vehiculoData)
        });
        if (!response.ok) throw new Error('Error al actualizar');
        return await response.json();
    } catch (error) {
        return null;
    }
}

// ============================================
// DATOS LOCALES
// ============================================

function initData() {
    if (!localStorage.getItem('vehiculos')) {
        localStorage.setItem('vehiculos', JSON.stringify([]));
    }
    if (!localStorage.getItem('initialized')) {
        localStorage.setItem('initialized', 'true');
    }
}

function getVehiculos() {
    const data = localStorage.getItem('vehiculos');
    return data ? JSON.parse(data) : [];
}

function saveVehiculos(vehiculos) {
    localStorage.setItem('vehiculos', JSON.stringify(vehiculos));
    window.dispatchEvent(new StorageEvent('storage', {
        key: 'vehiculos',
        newValue: JSON.stringify(vehiculos)
    }));
}

// ============================================
// UTILIDADES DE IMAGEN
// ============================================

function obtenerNombreImagen() {
    const input = document.getElementById('ofertaImagen');

    if (input.files.length > 0) {
        return input.files[0].name;
    }

    return 'default.jpg';
}

function fileToBase64(file) {
    return new Promise(function(resolve, reject) {
        const reader = new FileReader();
        reader.onload = function(e) {
            resolve(e.target.result);
        };
        reader.onerror = function(e) {
            reject(e);
        };
        reader.readAsDataURL(file);
    });
}

function validarImagen(file) {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    const maxSize = 5 * 1024 * 1024;

    if (allowedTypes.indexOf(file.type) === -1) {
        return { valid: false, message: 'Formato no valido. Usa JPG, PNG o WebP' };
    }

    if (file.size > maxSize) {
        return { valid: false, message: 'La imagen es demasiado grande. Max. 5MB' };
    }

    return { valid: true, message: 'OK' };
}

function comprimirImagen(base64, maxWidth, quality) {
    maxWidth = maxWidth || 800;
    quality = quality || 0.8;

    return new Promise(function(resolve) {
        const img = new Image();

        img.onload = function() {
            let width = img.width;
            let height = img.height;

            if (width > maxWidth) {
                height = Math.round((height * maxWidth) / width);
                width = maxWidth;
            }

            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');

            // Fondo blanco para evitar transparencias en PNG
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, width, height);
            ctx.drawImage(img, 0, 0, width, height);

            resolve(canvas.toDataURL('image/jpeg', quality));
        };

        img.onerror = function() {
            resolve(base64);
        };

        img.src = base64;
    });
}

// ============================================
// TOAST
// ============================================

function mostrarToast(mensaje, tipo) {
    tipo = tipo || 'success';
    const existing = document.querySelector('.toast-notification');
    if (existing) existing.remove();

    const colors = {
        success: '#D4AF37',
        error: '#ef4444',
        warning: '#f59e0b'
    };

    const toast = document.createElement('div');
    toast.className = 'toast-notification';

    const bgColor = colors[tipo] || colors.success;
    const textColor = tipo === 'error' ? 'white' : '#0a0a0a';

    toast.style.cssText = 'position: fixed; bottom: 2rem; right: 2rem; background: ' + bgColor + '; color: ' + textColor + '; padding: 1rem 2rem; border-radius: 8px; font-weight: 600; z-index: 9999; animation: slideUp 0.3s ease; font-family: Inter, sans-serif; box-shadow: 0 4px 12px rgba(0,0,0,0.3);';
    toast.textContent = mensaje;
    document.body.appendChild(toast);

    setTimeout(function() {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(20px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(function() {
            toast.remove();
        }, 300);
    }, 3000);
}

if (!document.getElementById('app-styles')) {
    const style = document.createElement('style');
    style.id = 'app-styles';
    style.textContent = '@keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }';
    document.head.appendChild(style);
}

/*// ==============================
// 🚀 PUBLICAR VEHÍCULO
// ==============================
function activarFormularioPublicar() {
    const form = document.getElementById('formPublicar');

    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const data = {
            modelo: document.getElementById('modelo').value,
            marca: document.getElementById('marca').value,
            anyo: document.getElementById('anyo').value,
            descripcion: document.getElementById('descripcion').value,
            imagen: document.getElementById('imagen').value
        };

        try {
            const res = await fetch('/api/vehiculos', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!res.ok) throw new Error();

            alert('Vehículo guardado en BD');

            form.reset();

        } catch (error) {
            alert('Error al guardar');
            console.error(error);
        }
    });
}*/

// ==============================
// 🚀 CREAR OFERTA (FORM → API → BD)
// ==============================
async function crearOferta(event) {
    event.preventDefault(); // 🔴 evita que recargue la página

    // recoger datos del formulario
    const data = {
        marca: document.getElementById('ofertaMarca').value,
        modelo: document.getElementById('ofertaModelo').value,
        tipo: document.getElementById('ofertaTipo').value,
        anyo: document.getElementById('ofertaAnio').value,
        precio: document.getElementById('ofertaPrecio').value,
        matricula: document.getElementById('ofertaMatricula').value,
        descripcion: document.getElementById('ofertaDescripcion').value,
        imagen: obtenerNombreImagen() // 👇 función abajo
    };

    try {
		const res = await fetch('http://localhost:8088/api/admin/vehiculos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (!res.ok) throw new Error();

        alert('✅ Vehículo guardado en base de datos');

        document.getElementById('ofertaForm').reset();
        removeImage(); // limpia preview si tienes esa función

    } catch (error) {
        console.error(error);
        alert('❌ Error al guardar en BD');
    }
}