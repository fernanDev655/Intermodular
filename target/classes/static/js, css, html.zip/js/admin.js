// js/admin.js
// Panel de Administración - AutoElite
// API: Spring Boot - /api/admin/users

const API_BASE_URL = '/api';

// ============ UTILIDADES HTTP ============
const apiFetch = async (url, options = {}) => {
    const defaultOptions = {
        credentials: 'include', // Importante para sesiones
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        }
    };
    
    try {
        const response = await fetch(url, { ...defaultOptions, ...options });
        
        if (response.status === 401) {
            window.location.href = '/concesionario/login.html';
            return null;
        }
        if (response.status === 403) {
            alert('No tienes permisos de administrador');
            window.location.href = '/concesionario/index.html';
            return null;
        }
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP ${response.status}: ${errorText}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error API:', error);
        throw error;
    }
};

// ============ CARGAR USUARIOS ============
const loadUsuarios = async () => {
    try {
        const usuarios = await apiFetch(`${API_BASE_URL}/admin/users`);
        if (usuarios) {
            console.log('Usuarios cargados:', usuarios);
            
            renderUsuarios(usuarios);
            updateStats(usuarios);
        }
    } catch (error) {
        mostrarNotificacion('Error al cargar usuarios', 'error');
        console.error(error);
    }
};

// ============ RENDERIZAR TABLA ============
const renderUsuarios = (usuarios) => {
    const tbody = document.querySelector('#tablaUsuarios tbody');
    if (!tbody) return;

    if (!usuarios || usuarios.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 2rem; color: #888;">
                    No hay usuarios registrados
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = usuarios.map(u => `
        <tr data-id="${u.id}">
            <td>${escapeHtml(u.nombre || '-')}</td>
            <td>${escapeHtml(u.apellidos || '-')}</td>
            <td>${escapeHtml(u.dni || '-')}</td>
            <td>${escapeHtml(u.telefono || '-')}</td>
            <td>${escapeHtml(u.email || '-')}</td>
            <td>
                <span class="badge-rol rol-${(u.role || 'USER').toLowerCase()}">
                    ${formatearRol(u.role)}
                </span>
            </td>
            <td class="acciones-cell">
                <button onclick="abrirModalEditar(${u.id})" class="btn btn-sm btn-editar" title="Editar">
                    ✏️
                </button>
                <button onclick="eliminarUsuario(${u.id})" class="btn btn-sm btn-eliminar" title="Eliminar">
                    🗑️
                </button>
            </td>
        </tr>
    `).join('');
};

const escapeHtml = (text) => {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
};

const formatearRol = (role) => {
    const roles = {
        'USER': 'Cliente',
        'CLIENTE': 'Cliente',
        'MECANICO': 'Mecánico',
        'COMERCIAL': 'Comercial',
        'ADMIN': 'Admin'
    };
    return roles[role?.toUpperCase()] || role || 'Usuario';
};

// ============ ESTADÍSTICAS ============
const updateStats = (usuarios) => {
    const statUsuarios = document.getElementById('statUsuarios');
    const statVehiculos = document.getElementById('statVehiculos');
    const statReparaciones = document.getElementById('statReparaciones');
    
    if (statUsuarios) statUsuarios.textContent = usuarios.length;
    
    // Conteo por roles para log
    const porRol = usuarios.reduce((acc, u) => {
        const rol = (u.role || 'USER').toUpperCase();
        acc[rol] = (acc[rol] || 0) + 1;
        return acc;
    }, {});
    console.log('Distribución de usuarios:', porRol);
};

// ============ ELIMINAR USUARIO ============
const eliminarUsuario = async (id) => {
    // No permitir eliminarse a sí mismo
    const currentUser = getCurrentUser();
    if (currentUser && currentUser.id === id) {
        alert('No puedes eliminar tu propia cuenta');
        return;
    }

    if (!confirm('¿Eliminar este usuario permanentemente?')) return;

    try {
        await apiFetch(`${API_BASE_URL}/admin/users/${id}`, {
            method: 'DELETE'
        });
        
        mostrarNotificacion('Usuario eliminado', 'success');
        await loadUsuarios();
        
    } catch (error) {
        mostrarNotificacion('Error al eliminar', 'error');
    }
};

// ============ EDITAR USUARIO ============
let usuarioEditandoId = null;

const abrirModalEditar = async (id) => {
    try {
        const usuario = await apiFetch(`${API_BASE_URL}/admin/users/${id}`);
        if (!usuario) return;
        
        usuarioEditandoId = id;
        
        document.getElementById('editNombre').value = usuario.nombre || '';
        document.getElementById('editApellidos').value = usuario.apellidos || '';
        document.getElementById('editDni').value = usuario.dni || '';
        document.getElementById('editTelefono').value = usuario.telefono || '';
        document.getElementById('editEmail').value = usuario.email || '';
        document.getElementById('editRole').value = (usuario.role || 'USER').toUpperCase();
        
        document.getElementById('modalEditar').classList.add('active');
        
    } catch (error) {
        mostrarNotificacion('Error al cargar usuario', 'error');
    }
};

const cerrarModalEditar = () => {
    document.getElementById('modalEditar').classList.remove('active');
    usuarioEditandoId = null;
    document.getElementById('formEditarUsuario').reset();
};

const guardarEdicion = async (e) => {
    e.preventDefault();
    if (!usuarioEditandoId) return;
    
    const datos = {
        nombre: document.getElementById('editNombre').value.trim(),
        apellidos: document.getElementById('editApellidos').value.trim() || null,
        dni: document.getElementById('editDni').value.trim() || null,
        telefono: document.getElementById('editTelefono').value.trim() || null,
        email: document.getElementById('editEmail').value.trim(),
        role: document.getElementById('editRole').value.toUpperCase()
    };
    
    try {
        await apiFetch(`${API_BASE_URL}/admin/users/${usuarioEditandoId}`, {
            method: 'PUT',
            body: JSON.stringify(datos)
        });
        
        cerrarModalEditar();
        mostrarNotificacion('Usuario actualizado', 'success');
        await loadUsuarios();
        
    } catch (error) {
        mostrarNotificacion('Error al actualizar', 'error');
    }
};

// ============ NOTIFICACIONES ============
const mostrarNotificacion = (mensaje, tipo = 'info') => {
    const notif = document.createElement('div');
    notif.className = `notificacion notificacion-${tipo}`;
    notif.textContent = mensaje;
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 9999;
        animation: slideIn 0.3s ease;
        background: ${tipo === 'success' ? '#28a745' : tipo === 'error' ? '#dc3545' : '#d4af37'};
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    
    document.body.appendChild(notif);
    
    setTimeout(() => {
        notif.style.animation = 'slideOut 0.3s ease forwards';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
};

// ============ INICIALIZACIÓN ============
document.addEventListener('DOMContentLoaded', () => {
    // Verificar auth (de app.js)
    if (typeof checkAuth === 'function') {
        checkAuth(['admin']);
    }
    
    // Cargar usuarios
    loadUsuarios();
    
    // Formulario edición
    const form = document.getElementById('formEditarUsuario');
    if (form) form.addEventListener('submit', guardarEdicion);
    
    // Cerrar modal al click fuera
    const modal = document.getElementById('modalEditar');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) cerrarModalEditar();
        });
    }
});

// logout
const logout = () => {
    localStorage.removeItem("currentUser");
    localStorage.removeItem("accesoEspecial");
    window.location.href = "/concesionario/index.html";
};