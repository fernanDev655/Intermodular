// login.js - Manejo de login con códigos de acceso corporativo

const API_URL = 'http://localhost:8088/api'; // Ajusta según tu configuración

// Mapa de códigos a roles
const CODIGOS_ROLES = {
    'icqb': ['mecanico', 'comercial', 'admin'], // Código especial permite estos roles
    'meca': ['mecanico'],
    'vent': ['comercial'],
    'admn': ['admin']
};

let rolSeleccionado = 'cliente'; // Por defecto

async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    const rolSelect = document.getElementById('loginRol');
    
    // Si hay selector visible, usar el rol seleccionado
    if (rolSelect && rolSelect.style.display !== 'none') {
        rolSeleccionado = rolSelect.value;
    }
    
    const btnSubmit = document.querySelector('.btn-submit');
    const textoOriginal = btnSubmit.innerHTML;
    btnSubmit.disabled = true;
    btnSubmit.innerHTML = '<span>Verificando...</span>';
    
    try {
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                password: password
            }),
            credentials: 'include' // Importante para que la sesión (cookie) funcione
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => null);
            throw new Error(errorData?.message || 'Credenciales inválidas');
        }
        
        const user = await response.json();
        console.log('Usuario autenticado:', user);
        
        // ============================================
        // GUARDAR USUARIO EN LOCALSTORAGE - ESTO FALTABA
        // ============================================
        localStorage.setItem("currentUser", JSON.stringify(user));
        
        // Verificar que el rol del usuario coincida con lo esperado
        const rolNormalizado = user.role.toLowerCase();
        
        // Redirigir según el rol
        const redirectUrl = obtenerRedirectPorRol(rolNormalizado);
        
        mostrarExito('¡Bienvenido! Redirigiendo...');
        
        setTimeout(() => {
            window.location.href = redirectUrl;
        }, 800);
        
    } catch (error) {
        mostrarError(error.message || 'Error al iniciar sesión');
        btnSubmit.disabled = false;
        btnSubmit.innerHTML = textoOriginal;
    }
}

function verificarCodigo() {
    const codigo = document.getElementById('codigoAcceso').value.toLowerCase().trim();
    const mensaje = document.getElementById('mensajeCodigo');
    const rolSelector = document.getElementById('rolSelector');
    
    // Buscar el código en el mapa
    const rolesPermitidos = CODIGOS_ROLES[codigo];
    
    if (rolesPermitidos) {
        mensaje.innerHTML = '<span class="success-icon">✓</span> Acceso concedido. Selecciona tu rol.';
        mensaje.className = 'code-message success';
        
        // Configurar el selector con los roles permitidos
        const select = document.getElementById('loginRol');
        select.innerHTML = ''; // Limpiar opciones
        
        rolesPermitidos.forEach(rol => {
            const option = document.createElement('option');
            option.value = rol;
            option.textContent = rol.charAt(0).toUpperCase() + rol.slice(1);
            select.appendChild(option);
        });
        
        // Añadir cliente como opción siempre disponible
        if (!rolesPermitidos.includes('cliente')) {
            const optionCliente = document.createElement('option');
            optionCliente.value = 'cliente';
            optionCliente.textContent = 'Cliente';
            select.insertBefore(optionCliente, select.firstChild);
        }
        
        rolSelector.style.display = 'block';
        rolSeleccionado = select.value;
        
        // Scroll suave al selector
        rolSelector.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        
    } else {
        mensaje.innerHTML = '<span class="error-icon">✕</span> Código inválido';
        mensaje.className = 'code-message error';
        rolSelector.style.display = 'none';
    }
}

function obtenerRedirectPorRol(rol) {
    const redirects = {
        'cliente': 'coleccion.html',
        'user': 'coleccion.html', // Por si el rol es USER
        'mecanico': 'mecanico-panel.html',
        'comercial': 'comercial-panel.html',
        'admin': 'admin-panel.html',
        'administrador': 'admin-panel.html'
    };
    
    return redirects[rol] || 'index.html';
}

function mostrarError(mensaje) {
    let errorDiv = document.getElementById('errorMensaje');
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.id = 'errorMensaje';
        errorDiv.className = 'error-message';
        const form = document.getElementById('loginForm');
        form.parentNode.insertBefore(errorDiv, form);
    }
    errorDiv.innerHTML = `<span class="error-icon">✕</span> ${mensaje}`;
    errorDiv.style.display = 'block';
    
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 5000);
}

function mostrarExito(mensaje) {
    let successDiv = document.getElementById('successMensaje');
    if (!successDiv) {
        successDiv = document.createElement('div');
        successDiv.id = 'successMensaje';
        successDiv.className = 'success-message';
        const form = document.getElementById('loginForm');
        form.parentNode.insertBefore(successDiv, form);
    }
    successDiv.innerHTML = `<span class="success-icon">✓</span> ${mensaje}`;
    successDiv.style.display = 'block';
}

// Verificar si viene de registro exitoso
document.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('registro') === 'exitoso') {
        mostrarExito('¡Cuenta creada! Ahora puedes iniciar sesión');
    }
});