// register.js - Manejo de registro de clientes

const API_URL = 'http://localhost:8088/api'; // Ajusta según tu configuración

async function handleRegister(event) {
    event.preventDefault();
    
    const nombre = document.getElementById('regNombre').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const password2 = document.getElementById('regPassword2').value;
    
    // Validaciones cliente
    if (password !== password2) {
        mostrarError('Las contraseñas no coinciden');
        return;
    }
    
    if (password.length < 6) {
        mostrarError('La contraseña debe tener al menos 6 caracteres');
        return;
    }
    
    const btnSubmit = document.querySelector('.btn-submit');
    const textoOriginal = btnSubmit.innerHTML;
    btnSubmit.disabled = true;
    btnSubmit.innerHTML = '<span>Creando cuenta...</span>';
    
    try {
        const response = await fetch(`${API_URL}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nombre: nombre,
                email: email,
                password: password
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => null);
            throw new Error(errorData?.message || 'Error al crear la cuenta');
        }
        
        const user = await response.json();
        
        // Registro exitoso - redirigir al login
        mostrarExito('¡Cuenta creada exitosamente! Redirigiendo...');
        
        setTimeout(() => {
            window.location.href = 'login.html?registro=exitoso';
        }, 1500);
        
    } catch (error) {
        mostrarError(error.message || 'Error de conexión con el servidor');
        btnSubmit.disabled = false;
        btnSubmit.innerHTML = textoOriginal;
    }
}

function mostrarError(mensaje) {
    // Crear o actualizar mensaje de error
    let errorDiv = document.getElementById('errorMensaje');
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.id = 'errorMensaje';
        errorDiv.className = 'error-message';
        document.querySelector('.auth-card').insertBefore(errorDiv, document.getElementById('registerForm'));
    }
    errorDiv.innerHTML = `<span class="error-icon">✕</span> ${mensaje}`;
    errorDiv.style.display = 'block';
    
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 5000);
}

function mostrarExito(mensaje) {
    let successDiv = document.getElementById('successMensaje');
    if (!successDiv) {
        successDiv = document.createElement('div');
        successDiv.id = 'successMensaje';
        successDiv.className = 'success-message';
        document.querySelector('.auth-card').insertBefore(successDiv, document.getElementById('registerForm'));
    }
    successDiv.innerHTML = `<span class="success-icon">✓</span> ${mensaje}`;
    successDiv.style.display = 'block';
}