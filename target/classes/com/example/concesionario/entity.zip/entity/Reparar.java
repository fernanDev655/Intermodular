package com.example.concesionario.entity;

public class Reparar {
	private int id_mecanico;
	private int id_vehiculo;
	private int id_reparacion;

	public Reparar(int id_mecanico, int id_vehiculo, int id_reparacion) {
		super();
		this.id_mecanico = id_mecanico;
		this.id_vehiculo = id_vehiculo;
		this.id_reparacion = id_reparacion;
	}

	public int getId_mecanico() {
		return id_mecanico;
	}

	public void setId_mecanico(int id_mecanico) {
		this.id_mecanico = id_mecanico;
	}

	public int getId_vehiculo() {
		return id_vehiculo;
	}

	public void setId_vehiculo(int id_vehiculo) {
		this.id_vehiculo = id_vehiculo;
	}

	public int getId_reparacion() {
		return id_reparacion;
	}

	public void setId_reparacion(int id_reparacion) {
		this.id_reparacion = id_reparacion;
	}

	@Override
	public String toString() {
		return "Reparar [id_mecanico=" + id_mecanico + ", id_vehiculo=" + id_vehiculo
				+ ", id_reparacion=" + id_reparacion + "]";
	}

}
