package com.example.concesionario.entity;

import java.time.LocalDateTime;

public class Reparacion {
	private Integer id;
	private LocalDateTime fecha;
	private String tipo; // General, chapa, pintura, electrica, aire acondicionado, etc.
	private double coste;

	public Reparacion(Integer id, LocalDateTime fecha, String tipo, double coste) {
		super();
		this.id = id;
		this.fecha = fecha;
		this.tipo = tipo;
		this.coste = coste;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getFecha() {
		return fecha;
	}

	public void setFecha(LocalDateTime fecha) {
		this.fecha = fecha;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public double getCoste() {
		return coste;
	}

	public void setCoste(double coste) {
		this.coste = coste;
	}

	@Override
	public String toString() {
		return "Reparacion [ID = " + id + ", fecha = " + fecha + ", tipo = " + tipo + ", coste = " + coste + "]";
	}

}
