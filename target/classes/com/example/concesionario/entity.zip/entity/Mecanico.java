package com.example.concesionario.entity;

public class Mecanico extends Empleado {
	private int trabajos_activos;

	public Mecanico(Integer id, String nombre, String apellido, String puesto, double sueldo, Integer id_mecanico,
			int trabajos_activos) {
		super(id, nombre, apellido, puesto, sueldo);
		this.trabajos_activos = trabajos_activos;
	}

	public int getTrabajos_activos() {
		return trabajos_activos;
	}

	public void setTrabajos_activos(int trabajos_activos) {
		this.trabajos_activos = trabajos_activos;
	}

	@Override
	public String toString() {
		return "Mecanico [id=" + getId() +  "trabajos_activos=" + trabajos_activos + "]";
	}

}