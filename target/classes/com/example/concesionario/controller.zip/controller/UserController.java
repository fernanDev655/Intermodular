package com.example.concesionario.controller;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.web.bind.annotation.*;

import com.example.concesionario.dto.UserRequest;
import com.example.concesionario.entity.User;
import com.example.concesionario.exception.DataAccessException;
import com.example.concesionario.repository.UserRepository;

@RestController
@RequestMapping("/api/admin/users")
public class UserController {
	private final DataSource ds;

    public UserController(DataSource ds) {
    	this.ds = ds;
    }
    
    @GetMapping
    public List<User> index() throws SQLException {
    	System.out.println("HOLA");
    	try (Connection con = ds.getConnection()) {
    		UserRepository repo = new UserRepository(con);
    	    return repo.findAll();
    	 } catch (SQLException e) {
    	        throw new DataAccessException(e);
    	 }
    }
    
    @GetMapping("/{id}")
    public User show(@PathVariable int id) {
        try (Connection con = ds.getConnection()) {
        	UserRepository repo = new UserRepository(con);
            return repo.find(id);
        } catch (SQLException e) {
            throw new DataAccessException(e);
        }
    }

    @PostMapping
    public User store(@RequestBody UserRequest req) {
        try (Connection con = ds.getConnection()) {
        	UserRepository repo = new UserRepository(con);
        	User user = map(req);
            repo.insert(user);
            return user;
        } catch (SQLException e) {
            throw new DataAccessException(e);
        }
    }

    @PutMapping("/{id}")
    public User update(@PathVariable int id, @RequestBody UserRequest req) {
        try (Connection con = ds.getConnection()) {
        	UserRepository repo = new UserRepository(con);
            User user = map(req);
            user.setId(id);
            repo.update(user);
            return user;
        } catch (SQLException e) {
            throw new DataAccessException(e);
        }
    }

    @DeleteMapping("/{id}")
    public void destroy(@PathVariable int id) {
        try (Connection con = ds.getConnection()) {
        	UserRepository repo = new UserRepository(con);
            repo.delete(id);
        } catch (SQLException e) {
            throw new DataAccessException(e);
        }
    }
    
     private User map(UserRequest req) {
    	return new User(
    		null,
    		req.nombre(),
    		req.apellidos(),
    		req.dni(),
    		req.telefono(),
    		req.email(),
    		req.password(),
    		"USER"
    	);
    }
}
