package com.example.concesionario.controller;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.web.bind.annotation.*;

import com.example.concesionario.entity.Reparar;
import com.example.concesionario.exception.DataAccessException;
import com.example.concesionario.repository.RepararRepository;

@RestController
@RequestMapping("/api/admin/reparaciones_vehiculos")
public class RepararAdminController {
	private final DataSource ds;

    public RepararAdminController(DataSource ds) {
    	this.ds = ds;
    }
    
    @GetMapping
    public List<Reparar> index() throws SQLException {
    	System.out.println("HOLA");
    	try (Connection con = ds.getConnection()) {
    	    RepararRepository repo = new RepararRepository(con);
    	    return repo.findAll();
    	 } catch (SQLException e) {
    	        throw new DataAccessException(e);
    	 }
    }
    
    @GetMapping("/{id}")
    public Reparar show(@PathVariable int id) {
        try (Connection con = ds.getConnection()) {
            RepararRepository repo = new RepararRepository(con);
            return repo.find(id);
        } catch (SQLException e) {
            throw new DataAccessException(e);
        }
    }

    /* @PostMapping
    public Reparar store(@RequestBody PeliculaRequest req) {
        try (Connection con = ds.getConnection()) {
            RepararRepository repo = new RepararRepository(con);
            Reparar pelicula = map(req);
            repo.insert(pelicula);
            return pelicula;
        } catch (SQLException e) {
            throw new DataAccessException(e);
        }
    }

    @PutMapping("/{id}")
    public Reparar update(@PathVariable int id, @RequestBody PeliculaRequest req) {
        try (Connection con = ds.getConnection()) {
            RepararRepository repo = new RepararRepository(con);
            Reparar pelicula = map(req);
            pelicula.setId(id);
            repo.update(pelicula);
            return pelicula;
        } catch (SQLException e) {
            throw new DataAccessException(e);
        }
    }

    @DeleteMapping("/{id}")
    public void destroy(@PathVariable int id) {
        try (Connection con = ds.getConnection()) {
            RepararRepository repo = new RepararRepository(con);
            repo.delete(id);
        } catch (SQLException e) {
            throw new DataAccessException(e);
        }
    }
    
    private Reparar map(PeliculaRequest req) {
    	return new Reparar(
    		null,
    		req.titulo(),
    		req.anyo(),
    		req.duracion(),
    		req.sinopsis(),
    		req.directorId()
    	);
    }*/
}
