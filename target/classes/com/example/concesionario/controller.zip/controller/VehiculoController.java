package com.example.concesionario.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.web.bind.annotation.*;

import com.example.concesionario.db.DB;
import com.example.concesionario.dto.VehiculoRequest;
import com.example.concesionario.entity.Vehiculo;
import com.example.concesionario.exception.DataAccessException;
import com.example.concesionario.repository.VehiculoRepository;

@RestController
@RequestMapping("/api/admin/vehiculos")
public class VehiculoController {
	private final DataSource ds;

	public VehiculoController(DataSource ds) {
		this.ds = ds;
	}

	@GetMapping
	public List<Vehiculo> index() {
		try (Connection con = ds.getConnection()) {
			return new VehiculoRepository(con).findAll();
		} catch (SQLException e) {
			throw new DataAccessException(e);
		}
	}

	@GetMapping("/{id}")
	public Vehiculo show(@PathVariable int id) {
		try (Connection con = ds.getConnection()) {
			return new VehiculoRepository(con).find(id);
		} catch (SQLException e) {
			throw new DataAccessException(e);
		}
	}

	@PostMapping
	public Vehiculo store(@RequestBody VehiculoRequest req) {
		try (Connection con = ds.getConnection()) {
			VehiculoRepository repo = new VehiculoRepository(con);
			Vehiculo vehiculo = map(req);
			repo.insert(vehiculo);
			return vehiculo;
		} catch (SQLException e) {
			throw new DataAccessException(e);
		}
	}

	@PutMapping("/{id}")
	public Vehiculo update(@PathVariable int id, @RequestBody VehiculoRequest req) {
		try (Connection con = ds.getConnection()) {
			VehiculoRepository repo = new VehiculoRepository(con);
			Vehiculo vehiculo = map(req);
			vehiculo.setId(id);
			repo.update(vehiculo);
			return vehiculo;
		} catch (SQLException e) {
			throw new DataAccessException(e);
		}
	}

	@DeleteMapping("/{id}")
	public void destroy(@PathVariable int id) {
		try (Connection con = ds.getConnection()) {
			new VehiculoRepository(con).delete(id);
		} catch (SQLException e) {
			throw new DataAccessException(e);
		}
	}

	private Vehiculo map(VehiculoRequest req) {
		return new Vehiculo(null, req.marca(), req.modelo(), req.anyo(), req.precio(), req.categoria(), req.matricula(),
				req.descripcion(), req.imagen());
	}
}
