package com.example.concesionario.controller;

import java.io.IOException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.example.concesionario.entity.VehiculoImagen;
import com.example.concesionario.exception.DataAccessException;
import com.example.concesionario.helper.StorageHelper;
import com.example.concesionario.repository.VehiculoImagenRepository;
import com.example.concesionario.repository.VehiculoRepository;
import com.example.concesionario.validation.ImageValidator;

@RestController
@RequestMapping("/api/admin/vehiculo/{vehiculoId}/imagenes")
public class VehiculoImagenController extends BaseController {

	private final StorageHelper storage;

	public VehiculoImagenController(DataSource ds, StorageHelper storage) {
		super(ds);
		this.storage = storage;
	}

	// CREATE
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public VehiculoImagen store(@PathVariable int vehiculoId, @RequestParam("file") MultipartFile file) {

		try (Connection con = ds.getConnection()) {

			// validar existencia
			new VehiculoRepository(con).findOrThrow(vehiculoId);
			
			ImageValidator.validate(file);

			String url = storage.save(file, "vehiculo");

			VehiculoImagenRepository repo = new VehiculoImagenRepository(con);

			VehiculoImagen img = new VehiculoImagen(null, vehiculoId, url);

			return repo.insert(img);

		} catch (SQLException e) {
			throw new DataAccessException(e);
		} catch (IOException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// DELETE
	@DeleteMapping("/{id}")
	public void delete(@PathVariable int id) {

		try (Connection con = ds.getConnection()) {

			VehiculoImagenRepository repo = new VehiculoImagenRepository(con);

			// opcional: obtener url antes de borrar
			VehiculoImagen img = repo.find(id);

			repo.delete(id);

			if (img != null && img.getUrl() != null) {
				storage.deleteByUrl(img.getUrl());
			}

		} catch (SQLException e) {
			throw new DataAccessException(e);
		}
	}
}